

#set your working directory


##################################
# FOR LECTURE
##################################


# open data file
newData = read.table("dfData.txt", header=TRUE)
View(newData)

newData$Y[29]=20

model1=lm(Y~X, data=newData)

summary(model1)


#get the predicted values
newData$fitted = round(fitted(model1),3)
View(newData)

#get residuals
newData$resid = round(resid(model1),3)  # the residual

newData$Y2 = newData$fitted + newData$resid  # if observed = model + error then sales2 should equal are observed values!!
View(newData)

newData$rstandard = round(rstandard(model1),3)  #the standardized (z scored) residual
newData$rstudent = round(rstudent(model1),3)  # the studentized (t-scored) residual

#get influence statistics
newData$dfbeta = round(dfbeta(model1),3)  #change in the beta weights if the item is deleted
newData$dffits = round(dffits(model1),3)  # standardized change in the predicted value for a case (z scored change)
newData$cooks = round(cooks.distance(model1),3)  #cook's distance 
newData$leverage = round(hatvalues(model1),3)  # leverage values, look for scores > 2 or 3 times the average
newData$covratio = round(covratio(model1),3)  # change in covariance ratio
View(newData)


#are there any points that we need to worry about.



######################################
# --- FOR WORKSHOP -----
######################################

album1<-read.delim("Album Sales 1.dat", header = TRUE)
View(album1)


#----run the simple linear regression model---
albumSales.1 <- lm(sales ~ adverts, data = album1)  #run the regression
summary(albumSales.1)  #get the summary statistics


album1$fitted = round(fitted(albumSales.1),3)  #get the predicted values
View(album1)


cor(album1$sales,album1$fitted)  # the correlation between the outcome and predicted is a measure of how good the model fits
cor(album1$sales,album1$fitted)^2  #square the correlation and it should match the Rsquared in the summary statistics



#get the residuals
album1$resid = round(resid(albumSales.1),3)
album1$rstandard = round(rstandard(albumSales.1),3)
View(album1)

album1$sales2 = album1$fitted + album1$resid  # if observed = model + error then sales2 should equal are observed values!!
View(album1)  #does sales2 = sales???

album1$dfbeta = round(dfbeta(albumSales.1),3)
album1$dffits = round(dffits(albumSales.1),3)
album1$rstudent = round(rstudent(albumSales.1),3)
album1$cooks = round(cooks.distance(albumSales.1),3)
album1$leverage = round(hatvalues(albumSales.1),3)
album1$covratio = round(covratio(albumSales.1),3)
View(album1)


# are there any observations that are outliers?
# are there any observations that are having a large influence?

#one way to assess whether items with large residuals are having an large influence we can examine these separately
#examine the standardized residuals (remember these are like zscores)
#let's pull out the observations that are more than 2SD away from the mean (0)

album1.largeResiduals = album1[abs(album1$rstandard) >=2,]  #unlike the textbook I used the absoltue value to do my evaluation
View(album1.largeResiduals)


#let's get the number of trials that exceeded our criterion
dim(album1.largeResiduals) #returns #rows, #columns in our dataframe.  Therefore the first number tells us how many obs have large residuals

#let's get the number of trials that exceed a criterion for the cook's distance
album1.largeCooks = album1[abs(album1$cooks) >=(4/200),]  #unlike the textbook I used the absoltue value to do my evaluation
View(album1.largeCooks)

#let's find out if removing these values changes our regression model
album1.smallCooks = album1[abs(album1$cooks) < (4/200),]  #create a new dataframe that contains only obs with small Cook's distance
albumSales.cooks = lm(sales~adverts,data=album1.smallCooks)  # run the regression on the new data set
summary(albumSales.cooks)

#may also be useful to plot the diagnostics
plot(album1$cooks)
plot(album1$leverage)

#plot our regression
scatter <- ggplot(album1, aes(adverts, sales)) +  #CREATE THE GRAPH OBJECT
  geom_point() + #ADD THE DATAPOINTS
  geom_abline(intercept=coef(albumSales.1)[1], slope=coef(albumSales.1)[2], colour="red")+
  geom_abline(intercept=coef(albumSales.cooks)[1], slope=coef(albumSales.cooks)[2], colour="blue")+ #ADD BEST FIT LINE (LINEAR MODEL), SET THE COLOUR, NO STANDARD ERROR
  labs(x = "Advertisements", y = "Sales") #ADD NICE LABELS  #DOESN'T USE THE OPTS COMMAND ANYMORE
scatter


#lets colour our "extreme" influencers (based on cook's distance)

album1$largeInfluence =0  #create a new variable and set it to 0
album1$largeInfluence[abs(album1$cooks)>(4/200)] = 1  #if the value exceeds our criterion, set it to 1
album1$largeInfluence = factor(album1$largeInfluence)  # so that it treats the new variable as categorical
View(album1)

scatter <- ggplot(album1, aes(adverts, sales, colour=largeInfluence)) +  #CREATE THE GRAPH OBJECT
  geom_point(aes(colour=largeInfluence)) + #ADD THE DATAPOINTS
  geom_abline(intercept=coef(albumSales.1)[1], slope=coef(albumSales.1)[2], colour="red")+
  geom_abline(intercept=coef(albumSales.cooks)[1], slope=coef(albumSales.cooks)[2], colour="blue")+ #ADD BEST FIT LINE (LINEAR MODEL), SET THE COLOUR, NO STANDARD ERROR
  labs(x = "Advertisements", y = "Sales") #ADD NICE LABELS  #DOESN'T USE THE OPTS COMMAND ANYMORE
scatter


######################################
######################################
#now lets do some different multiple regression methods
######################################
######################################


#----access the album2 data----
album2<-read.delim("Album Sales 2.dat", header = TRUE)
View(album2)


albumSales2.1<-lm(sales ~ adverts, data = album2) #OUR SIMPLE MODEL

######################################
#forced, enters everything at once
######################################

albumForced<-lm(sales ~ adverts + airplay + attract, data = album2)
summary(albumForced)
# What would we infer from this model?
#It has good fit (explains significant amount of variance)
#Each of the predictors is significant (contributes to the model)

######################################
#hierarchical
######################################
baseModel<-lm(sales ~ adverts + airplay, data = album2)  #the model based on past data
summary(baseModel)  # examine its fit


newModel<-lm(sales ~ adverts + airplay + attract, data = album2)  #add new variables based on theoretical importance #note you could do this more than once
summary(newModel)

anova(baseModel,newModel)  # see if the newmodel is better than the old model


########################
#stepwise forward
########################

# Requires the MASS library,  this should already be installed and active.  
# If not, install it and activate it.
#library(MASS)


# 1.  build a model with all of the relevant variables
completeModel<-lm(sales ~ adverts + airplay + attract, data = album2)  #add new variables based on theoretical importance #note you could do this more than once

# 2.  Run the stepwise function on the complete model
forwardModel <- stepAIC(completeModel, direction="forward")

# 3.  display results
forwardModel$anova# will provide a history of the interation of the model.  Our example only does one interation
summary(forwardModel)  

########################
#stepwise backward
########################
# 1.  build a model with all of the relevant variables
completeModel<-lm(sales ~ adverts + airplay + attract, data = album2)  #add new variables based on theoretical importance #note you could do this more than once

# 2.  Run the stepwise function on the complete model
backwardModel <- stepAIC(completeModel, direction="backward")

# 3.  display results
backwardModel$anova # will provide a history of the interation of the model.  Our example only does one interation
summary(backwardModel)  

########################
#stepwise both
########################
# 1.  build a model with all of the relevant variables
completeModel<-lm(sales ~ adverts + airplay + attract, data = album2)  #add new variables based on theoretical importance #note you could do this more than once

# 2.  Run the stepwise function on the complete model
bothModel <- stepAIC(completeModel, direction="both")

# 3.  display results
bothModel$anova # will provide a history of the interation of the model.  Our example only does one interation
summary(bothModel)  


########################
#use the all subsets regression
########################
# Requires the LEAPS library,  this should already be installed and active.  
# If not, install it and activate it.
#library(leaps)

# 1.  the model with all of the relevant variables
leapsModel<-regsubsets(sales ~ adverts + airplay + attract, data = album2,
                       nbest=2,
                       method="exhaustive")  #add new variables based on theoretical importance #note you could do this more than once
#leaps<-regsubsets(y~x1+x2+x3+x4,data=mydata,nbest=10)
# nbest indicates the number of subsets of each size to report. Here, the 1 best


# 3.  create a variable to see the output of the all subsets regression 

leapSummary = summary(leapsModel)  # we need to put it in a variable because there is lots to look at

leapData=as.data.frame(leapSummary$outmat)  # view the variables entered into the each model, outmat produces a matrix indicating which varibles were in which models
View(leapData)  #we needed to convert the matrix into a data.frame so that we could View() it!

#leap summary contains other useful information used to evaulate the model such as r2, adjusted r2, Marrow's Cp, and BIC (Like AIC)
#let's add this additional information to our summary data
leapData = cbind(leapData, leapSummary$rsq,leapSummary$adjr2,leapSummary$cp,leapSummary$bic)
View(leapData)

#one adised criterion for stopping is when Mallow's Cp is equal to the number of regressors +1
# this you will need to do in your head.

View(leapData)




########################
#Let's do an example using the data from mtcars
#-- you need to have the DATASETS package active
#-- if you don't have it, then install it.
#-- once it is installed activate it using library(datasets)
########################
library(datasets)

attach(mtcars)
View(mtcars)
#-- if you want to know more about the data set see
#-- Henderson and Velleman (1981), Building multiple regression models interactively. Biometrics, 37, 391–411.
